<?php include_once('header.php'); ?>

<?php $this->load->view($page); ?>

<?php include_once('footer.php'); ?>