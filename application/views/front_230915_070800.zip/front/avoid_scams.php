<div class="p-0 mt-lg-4 mt-md-3 mt-3"></div>

<div class="main-container" id="homepage">

<style>
    .faqdiv p{
        font-size:16px;
    }
</style>

    <div class="container mb-2 faqdiv">
            <br>
            <center>  <h1><b>Avoid Scams</b></h1></center>
          
            
         
            <p>Ask for proof of any vet checks, vaccinations (where applicable), microchipping, and/or pedigree papers. Be aware that the puppy should be at least eight weeks old at the point when it goes home with you. A responsible breeder would never send you home with a puppy younger than that. </p>
            
            <p>Breeders will often ask for a deposit before they will add you to their list and often it's legitimate, but before you hand over your hard-earned money, make sure all details are very clear. Deposit, payments, or when balance is due.</p>
            
            <p>We have verified the breeders that sell on our website. If you want to inquire about a particular breeder, feel free to use our Contact Us form. We will provide as much information as we can about any of our breeders.</p>
           
            
         
        
        </div>
        
        </div>