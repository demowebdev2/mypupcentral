<style>
    .ship_title {
        color: #8cc63f;
    }

    .ship_title i {
        color: #7a7a7a;
    }

    .ship_text 
    {
        font-size: 15px;
        color: #7a7a7a;
        line-height: 35px;
    }

    .air_travel {
        background-color: #a6e1ff;
    }

    .bg-gray {
        background-color: #f9f9f9;
    }

    .site-heading h2 {
        display: block;
        font-weight: 700;
        margin-bottom: 10px;
        text-transform: uppercase;
    }

    .site-heading h2 span {
        color: #ffaf5a;
    }

    .site-heading h4 {
        display: inline-block;
        padding-bottom: 20px;
        position: relative;
        text-transform: capitalize;
        z-index: 1;
    }

    .site-heading h4::before {
        background: #ffaf5a none repeat scroll 0 0;
        bottom: 0;
        content: "";
        height: 2px;
        left: 50%;
        margin-left: -25px;
        position: absolute;
        width: 50px;
    }

    .site-heading {
        margin-bottom: 60px;
        overflow: hidden;
        margin-top: -5px;
    }


    .features-items,
    .features-items .items-box {
        overflow: hidden;
    }

    .features-area .equal-height::after {
        background: #e7e7e7 none repeat scroll 0 0;
        content: "";
        height: 100%;
        position: absolute;
        right: -1px;
        top: 0;
        width: 1px;
    }

    .features-area.item-full .equal-height::before {
        background: #e7e7e7 none repeat scroll 0 0;
        content: "";
        height: 1px;
        position: absolute;
        bottom: -1px;
        right: 0;
        width: 100%;
    }

    .features-area .features-items .col-md-5,
    .features-area .features-items .col-md-7 {
        display: table-cell;
        float: none;
        vertical-align: middle;
    }

    .features-area .features-items.reversed .col-md-5,
    .features-area .features-items.reversed .col-md-7 {
        display: inline-block;
        float: left;
    }

    .features-area .features-items.reversed .info-box {
        float: right;
    }

    .features-area .features-items .item {
        padding: 15px 30px;
    }

    .features-area.item-full .features-items .item {
        padding: 30px;
    }

    .features-area .features-items .item h4 {
        position: relative;
    }

    .features-area.bottom-small {
        padding-bottom: 25px;
    }

    .features-area.default-padding.bottom-none {
        padding-bottom: 30px;
    }

    .features-area .item .icon {
        margin-bottom: 20px;
    }

    .features-area .item .info {}

    .features-area .item .icon i {
        background: #ffffff none repeat scroll 0 0;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;
        border-radius: 50%;
        -moz-box-shadow: 0 0 10px #cccccc;
        -webkit-box-shadow: 0 0 10px #cccccc;
        -o-box-shadow: 0 0 10px #cccccc;
        box-shadow: 0 0 10px #8cc63f;
        color: #8cc63f;
        display: inline-block;
        font-size: 30px;
        height: 100px;
        line-height: 100px;
        position: relative;
        text-align: center;
        width: 100px;
        z-index: 1;
    }

    .features-area .features-items .items-box i {
        background: transparent;
    }

    .features-area .item .icon {
        margin-bottom: 25px;
    }

    .features-area .features-items.icon-solid i {
        border-radius: inherit;
        -moz-box-shadow: 0 0 10px #cccccc;
        -webkit-box-shadow: 0 0 10px #cccccc;
        -o-box-shadow: 0 0 10px #cccccc;
        box-shadow: 0 0 10px #cccccc;
        color: #8cc63f;
        display: inline-block;
        font-size: 50px;
        height: 80px;
        line-height: 80px;
        position: relative;
        text-align: center;
        width: 80px;
    }


    .features-area .item .info h4 {
        font-weight: 600;
        text-transform: capitalize;
        font-size: 20px;
    }

    .features-area .item .info p {
        margin: 0;
    }

    .features-area .features-items.less-icon .items-box.inc-cell .item .info {
        padding-left: 0;
    }

    .features-area .features-items .items-box.inc-cell .item .info a {
        color: #666666;
        display: inline-block;
        margin-top: 15px;
        text-transform: uppercase;
    }

    .features-area .features-items .items-box.inc-cell .item .info a:hover {
        color: #ffaf5a;
    }

    .air_travel ol li {
        font-size: 15px;
        color: #363636;
    }
    .info_sub 
    {
        text-align: left;
        color: #292b2c;
        font-weight: bold;
        font-size: 20px;
        line-height: 30px;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<section>
    <img  src="<?= base_url() ?>assets/lazyload.gif" data-src="<?=base_url()?>assets/sta_banner.jpg" style="width:100%">
</section>
<div class="main-container" id="homepage" style="margin-bottom: -15px; padding-bottom: 0;">
    <div class="container text-center mb-2 pt-5 pb-2">
        <h1 class=""><b>Our Standards  </b></h1>
        <p class="ship_text pt-2 p-5">First and foremost we have a zero tolerance policy against puppy mills. 
            This includes sub-standard breeding practices where puppies are raised without proper socialization, exercise, 
            veterinary care, comfort, affection, and love. Any seller that is found to be in violation of our standards will be banned 
            from all of our platforms. We pledge to ensure every puppy is raised with the utmost attention, love, and care. 
        </p>
    </div>
    <section class=" mb-3 features-area ">
        <div class="text-center mb-2 pt-2">
            <div class="row features-items">
                <div class="col-md-6 col-sm-6 equal-height p-0">
                    <div class="item p-0">
                        <img src="<?= base_url() ?>assets/lazyload.gif" data-src="<?=base_url()?>assets/Cavapoo.jpg" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 equal-height">
                    <div class="item">
                        <!-- <div class="icon">
                            <i class="fa fa-comments" aria-hidden="true"></i>
                        </div> -->
                        <div class="info">
                            <h2 class="info_sub">All My Pup Central sellers agree to the following standards: </h2>
                            <ol class="" style="text-align:left; font-size: 16px; line-height: 35px;">
                                <li><i class="fa fa-check-circle" aria-hidden="true" style="padding-right: 10px;color:#a6e1ff;"></i> I will ensure every puppy has been well socialized and is prepared to join a new family.</li>
                                <li><i class="fa fa-check-circle" aria-hidden="true" style="padding-right: 10px;color:#a6e1ff;"></i> I will ensure every puppy is healthy and has been properly examined by a licensed veterinarian. </li>
                                <li><i class="fa fa-check-circle" aria-hidden="true" style="padding-right: 10px;color:#a6e1ff;"></i> I will maintain a safe, clean, and sanitary environment for my adult dogs and puppies.</li>
                                <li><i class="fa fa-check-circle" aria-hidden="true" style="padding-right: 10px;color:#a6e1ff;"></i> I will provide each buyer with health records- including vaccination and deworming records and basic diet information. </li>
                              
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>