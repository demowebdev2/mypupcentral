<div style="height:90px; display:none" class="app-content">

</div>
<footer class="main-footer web-content">
    <!--<div class="ftrpuppy">-->
    <!--<img src="<?= base_url(); ?>assets/front/img/footer_img.png" class="img-fluid">    </div>-->
    <div class="footer-content">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                    <div class="footer-col">
                        <h4 class="footer-title">Quick Links</h4>
                        <ul class="list-unstyled footer-nav">
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/faq" > FAQ </a>-->
                                <a href="<?= base_url() ?>"> Home </a>
                            </li>
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/faq" > FAQ </a>-->
                                <a href="<?= base_url() ?>success-stories"> Reviews </a>
                            </li>
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/faq" > FAQ </a>-->
                                <a href="<?= base_url() ?>faq"> FAQ </a>
                            </li>
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/anti-scam" > Anti-Scam </a>-->
                                <a href="<?= base_url(); ?>avoid-scams"> Avoid Scams </a>
                            </li>
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/terms" > Terms </a>-->
                                <a href="<?= base_url() ?>page/terms"> Terms </a>
                            </li>
                            <li>
                                <!--<a href="<?= base_url(); ?>assets/front/page/privacy" > Privacy </a>-->
                                <a href="<?= base_url() ?>page/terms"> Privacy </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                    <div class="footer-col">
                        <h4 class="footer-title">More</h4>
                        <ul class="list-unstyled footer-nav">

                            <li><a href="<?= base_url(); ?>contact"> Contact Us </a></li>
                            <li><a href="<?= base_url() ?>breeds_list">Puppies By Breed</a></li>
                            <li><a href="<?= base_url() ?>shipping">Puppy Travel</a></li>
                            <li><a href=" <?= base_url() ?>training">Training</a></li>
                            <li><a href="<?= base_url('sold'); ?>">Adopted Puppies</a></li>
                            <li><a href="<?= base_url('our-pledge'); ?>">Our Pledge</a></li>
                            <li><a href=" <?= base_url() ?>Page/blog">Blog</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-2 col-12">
                    <div class="footer-col">
                        <h4 class="footer-title">My Account</h4>
                        <ul class="list-unstyled footer-nav">
                            <li>
                                <a href="<?= base_url(); ?>login"> Log In </a>
                            </li>
                            <li><a href="<?= base_url(); ?>register"> Breeder Application </a></li>

                            <li><a href="<?= base_url(); ?>verify-breeder"> Verify Breeder </a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-12">
                    <div class="footer-col row">


                        <div class="col-sm-12 col-6 no-padding-lg">
                            <div class="">
                                <h4 class="footer-title ">Follow us on</h4>
                                <ul class="list-unstyled list-inline footer-nav social-list-footer social-list-color footer-nav-inline">
                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://www.facebook.com/mypupcentral/" target="_blank" title="Facebook">
                                            <i class="fab fa-facebook icstyle"></i>
                                        </a>
                                    </li>

                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://twitter.com/mypupcentral_" target="_blank" title="Twitter">
                                            <i class="fab fa-twitter-square icstyle"></i>
                                        </a>
                                    </li>

                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://youtube.com/@MyPupCentral" target="_blank" title="Youtube">
                                            <i class="fab fa-youtube-square icstyle"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://pin.it/39JDlE3" target="_blank" title="Pinterest">
                                            <i class="fab fa-pinterest-square icstyle"></i>
                                        </a>
                                    </li>

                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://www.instagram.com/mypupcentral/?hl=en" target="_blank" title="Instagram">
                                            <i class="fab fa-instagram icstyle"></i>
                                        </a>
                                    </li>

                                    <li>
                                        <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://www.tiktok.com/@mypupcentral?is_from_webapp=1&sender_device=pc" target="_blank" title="TikTok">
                                            <svg style="width: 35px;
height: 26.25px;
position: relative;
top:-7px;" xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
                                                <style>
                                                    svg {
                                                        fill: #7dd3ff
                                                    }
                                                </style>
                                                <path d="M448,209.91a210.06,210.06,0,0,1-122.77-39.25V349.38A162.55,162.55,0,1,1,185,188.31V278.2a74.62,74.62,0,1,0,52.23,71.18V0l88,0a121.18,121.18,0,0,0,1.86,22.17h0A122.18,122.18,0,0,0,381,102.39a121.43,121.43,0,0,0,67,20.14Z" />
                                            </svg>
                                        </a>
                                    </li>

                                    <li> <a class="icon-color " data-bs-placement="top" data-bs-toggle="tooltip" href="https://www.linkedin.com/company/my-pup-central/" target="_blank" title="LinkedIn ">
                                            <i class="fab fa-linkedin icstyle"></i></a></li>

                                </ul>
                                <ul class="list-unstyled footer-nav">
                                    <li><b>Address:</b> Dundee, Ohio, USA</li>
                                    <!--<li><b>Phone Number:</b></li>-->
                                </ul>

                                <h4 class="footer-title mt-3">Resources :</h4>
                                <a href="https://www.akc.org/" target="_blank"><img src="<?= base_url() ?>assets/lazyload.gif" data-src="<?= base_url() ?>uploads/akc.svg" width="90px"></a>&nbsp;
                                <a href="https://ofa.org/" target="_blank"><img src="<?= base_url() ?>assets/lazyload.gif" data-src="<?= base_url() ?>uploads/ofa.svg" width="90px"></a>

                            </div>
                        </div>
                    </div>
                </div>

                <div style="clear: both"></div>

                <div class="col-xl-12">
                    <!--<div class="text-center payment-method-logo">-->

                    <!--    <img src="<?= base_url(); ?>assets/front/images/paypal/payment.png" alt="Paypal" title="Paypal">-->
                    <!--</div>-->

                    <div class="copy-info text-center mt-4 pt-2">
                        © <?= date('Y') ?> My Pup Central. All Rights Reserved.

                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>

</div>



<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>



<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script src="<?= base_url(); ?>assets/front/plugins/modernizr/modernizr-custom.js"></script>




<script>
    $(document).on('click', '.addbookmark', function() {

        var token = "<?= $this->security->get_csrf_hash(); ?>";
        var id = $(this).attr("id");
        $(this).empty();
        $(this).append('<i class="fa fa-spinner fa-spin" style="font-size:24px"></i>');
        var getthis = $(this);
        $.ajax({
            type: "POST",
            url: "<?= base_url() ?>Home/update_bookmark",
            data: {
                id: id,
                choose: 1,
                'csrf_test_name': token,
            },
            dataType: "json",
            success: function(response) {
                $(getthis).empty();
                $(getthis).append('   <i class="far fa-heart"></i> <span>Save</span>');
                $(getthis).removeClass('addbookmark');
                $(getthis).addClass('removebookmark');
                $('.bookmark_count').empty();
                $('.bookmark_count').append(response.count);
            }
        });
    });

    $(document).on('click', '.removebookmark', function() {
        var url = $(location).attr('href');
        var fn = url.split('/').reverse()[0];

        var token = "<?= $this->security->get_csrf_hash(); ?>";
        var id = $(this).attr("id");
        $(this).empty();
        $(this).append('<i class="fa fa-spinner fa-spin" style="font-size:24px"></i>');
        var getthis = $(this);
        $.ajax({
            type: "POST",
            url: "<?= base_url() ?>Home/update_bookmark",
            data: {
                id: id,
                choose: 0,
                'csrf_test_name': token,
            },
            dataType: "json",
            success: function(response) {
                $(getthis).empty();
                $(getthis).append('   <i class="far fa-heart"></i> <span>Save</span>');
                $(getthis).removeClass('removebookmark');
                $(getthis).addClass('addbookmark');
                $('.bookmark_count').empty();
                $('.bookmark_count').append(response.count);
                if (fn == 'bookmarks') {
                    location.reload(true);
                }
            }
        });
    });
</script>


<script>
    var siteUrl = 'https://mypupcentral.com';
    var languageCode = 'en';
    var countryCode = 'US';
    var timerNewMessagesChecking = 60000;
    var isLogged = false;
    var isLoggedAdmin = false;


    var langLayout = {
        'hideMaxListItems': {
            'moreText': "View More",
            'lessText': "View Less"
        },
        'select2': {
            errorLoading: function() {
                return "The results could not be loaded."
            },
            inputTooLong: function(e) {
                var t = e.input.length - e.maximum,
                    n = 'Please delete ' + t + ' character';
                return t != 1 && (n += 's'), n
            },
            inputTooShort: function(e) {
                var t = e.minimum - e.input.length,
                    n = 'Please enter ' + t + ' or more characters';
                return n
            },
            loadingMore: function() {
                return "Loading more results…"
            },
            maximumSelected: function(e) {
                var t = 'You can only select ' + e.maximum + ' item';
                return e.maximum != 1 && (t += 's'), t
            },
            noResults: function() {
                return "No results found"
            },
            searching: function() {
                return "Searching…"
            }
        }
    };
    var fakeLocationsResults = "0";
    var stateOrRegionKeyword = "area:";
    var errorText = {
        errorFound: "Error found"
    };


    try {
        if (window.top.location !== window.location) {
            window.top.location.replace(siteUrl);
        }
    } catch (e) {
        console.error(e);
    };
</script>


<script>
    var maxSubCats = 3;
</script>

<script src="<?= base_url(); ?>assets/front/js/app.js"></script>
<script src="<?= base_url(); ?>assets/front/js/stellarnav.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick-theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">


<script>
    $(document).ready(function() {

        const lazyImages = document.querySelectorAll("img[data-src]");
        const options = {
            rootMargin: "0px 0px 100px 0px", // Adjust as needed for your design
            threshold: 0.1, // Adjust as needed
        };

        const lazyLoad = (entries, observer) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute("data-src");
                    observer.unobserve(img);
                }
            });
        };

        const observer = new IntersectionObserver(lazyLoad, options);

        lazyImages.forEach((img) => {
            observer.observe(img);
        });

    });
</script>



<script>
    $(document).ready(function() {

        $('.selecter').select2({
            language: langLayout.select2,
            width: '100%',
            dropdownAutoWidth: 'true',
            minimumResultsForSearch: Infinity
        });


        $('.large-data-selecter').select2({
            language: langLayout.select2,
            width: '100%',
            dropdownAutoWidth: 'true'
        });


        $('.share').ShareLink({
            title: 'My Pup Central',
            text: 'My Pup Central',
            url: 'https://mypupcentral.com/',
            width: 640,
            height: 480
        });


    });
</script>


<script>
    $(document).ready(function() {
        $(".postImg-slick").each(function() {
            var postImgSlick = $(this);
            var postImages = $(this).children();
            var counter = 1;

            if (postImages.length > 1) {
                postImages.each(function() {
                    jQuery('<img />').attr('src', $(this).attr('src')).on('load', function() {
                        counter++;
                        if (counter >= postImages.length) {
                            slickPostImage(postImgSlick);
                            counter = 1;
                        }
                    });
                });


                function slickPostImage(event) {
                    event.slick({
                        infinite: true,
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false,
                        arrows: true,
                        speed: 500,
                        cssEase: 'linear',
                        responsive: [{
                                breakpoint: 992,
                                settings: {
                                    infinite: true,
                                    slidesToShow: 1,
                                    slidesToScroll: 1,
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    infinite: true,
                                    slidesToShow: 1,
                                    slidesToScroll: 1,
                                }
                            },
                            {
                                breakpoint: 480,
                                settings: {
                                    infinite: true,
                                    slidesToShow: 1,
                                    slidesToScroll: 1,
                                }
                            }
                        ]
                    });
                }
            }
        });

        $(".postImg-slick").on("click", "button.slick-arrow", function(e) {
            e.preventDefault();
        });
    });
</script>






</body>

</html>