<div class="p-0 mt-lg-4 mt-md-3 mt-3"></div>

<div class="main-container">
    <div class="container">
        <div class="row">

              <h2 class="title-2">
                        <strong> Our Pledge</strong>
                    </h2>
                    
                    <h4>ZERO TOLERANCE POLICY OUR PLEDGE</h4>
                    
                    <p>We have ZERO TOLERANCE for puppy mills or puppies from back yard breeders raised without tender
loving care, socialization, exercise, comfort and affection or proper veterinarian care.</p>

<p>Our No Puppy Mill Pledge</p>

<p>
Any breeder found in violation of our pledge and standards will be permanently banned from all our
marketing platforms.</p>

<p>My Pups Central pledges to NOT support unethical breeders, substandard breeding practices or puppy mills.</p>

<p>My Pups Central pledges to ensure every single puppy is raised with the upmost attention, love and care.</p>

<p>Our Pledge and Breeder Code of Ethics (Our Standards) Breeders Agree to all of these:</p>

<p>I will ensure every puppy in the litter is well socialized.</p>

<p>I will ensure every puppy in the litter is healthy and has been properly screened by a licensed

veterinarian.</p>

<p>I will maintain a safe, clean and sanitary property.</p>

<p>I will comply with all federal, state or provincial and local government laws and regulations concerning
the keeping of dogs that I breed.</p>

<p>I will provide each buyer with health records including a diet, inoculation and parasite control record,and health guarantee.</p>

<p>I will provide each buyer with basic diet and care information</p>
                    
                    
        </div>
    </div>
</div>