<div class="p-0 mt-lg-4 mt-md-3 mt-3"></div>

<style>
    a:hover{
        color:#a6e1ff;
    }
</style>

<div class="container">
    <div class="text-center mb-5">

        <h1><b>
                Reviews </b>
        </h1>

    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-3">
            <center>
                <img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_1.jpg" alt="">
            </center>
        </div>

        <div class="col-md-5">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
                We adopted an Aussiedoodle…and then came back for a Bernedoodle because we loved our first one so much! They are both such amazing dogs!
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Angela Thomas</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2"></div>

    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>



    <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-5">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
                My wife and I brought home the last two remaining poms from a litter in July 2018. Since its been a couple years, I just wanted to share an update and let you know they’re doing great and we really, REALLY love them. We named them Stella and Weebs, and they’re the absolute goofiest, most charming little dogs; they make us laugh constantly. The two are inseparable, but have polar opposite personalities. We’re so happy we made the trip that summer day and did the “dumb” and impulsive thing–walk away with two puppies we love instead of one.
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Jason M.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-3">
            <center>
                <img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_2.jpg" alt="">

            </center>
        </div>
    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>

    <div class="row mt-5">
        <div class="col-md-2"></div>
        <div class="col-md-3">
            <center>
                <img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_3.jpg" alt="">
            </center>
        </div>

        <div class="col-md-5">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
                We love our pups! (2 Cavapoos) Crazy fun!! They have lit up our lives in such a good way!! They just graduated from puppy training.
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out"></a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2"></div>
    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>

    <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-5">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
                Gina and family we can’t thank-you enough for caring, loving and responsibly breeding puppies. Our Lola is loving and so friendly and we know it’s because of all the love you and your staff gave to her. Even our vet told us that Lola was a very healthy and happy puppy. We are in love with Lola she is the perfect puppy for us. We are always complemented on how beautiful Lola is. We have recommended your business to so many friends, coworkers and neighbors. I love texting you updates on how Lola is doing, and rest assure she’s being spoiled rotten.
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Roseanne Mazzella</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-3">
            <center>
                <img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt="">

            </center>
        </div>
    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>
    
    <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-8">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
                  
We brought home a beautiful Morkie female named Zennia. She is a sassy little lady and had a clean bill of health. Her new name is Gracie Laine and is a wonderful addition to our family. Reuben was very patient with me as I tried to choose between Zennia and Ion and I could not be happier with my choice.

            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Cheryl M.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2">
            <center>
                <!--<img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt=""> -->

            </center>
        </div>
    </div>
    
     <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>
    
    
      <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-8">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
          I recently purchased a 10-week-old Morkie from Reuben. I was very impressed with every aspect of my purchase. I thought I would drive Reuben crazy with my multitude of questions but he answered every question promptly and clearly. When my puppy was delivered, she was happy and healthy and totally made herself at home. It was clear that she had received a lot of love and was socialized. If I decide to buy another puppy in the future, Reuben's website will be my first to look at.
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Hazel S.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2">
            <center>
                <!--<img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt=""> -->

            </center>
        </div>
    </div>
    
     <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>
    
    
      <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-8">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
       I bought a cockapoo from Emily and she made the process seamless and quick! She is a great communicator and made sure my puppy arrived to me safely and provided a lot of information on the breed.


            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Aliyah A.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2">
            <center>
                <!--<img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt=""> -->

            </center>
        </div>
    </div>
    
     <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>
    
    
      <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-8">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
           This was the first puppy I have ever purchased and Emily made the process super easy and super smooth. Puppy arrived safe and sound, it is obvious puppy was given lots of love and care from how sweet he is. My daughter and I are extremely happy with our new addition.
            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Awilda & Vanessa C.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2">
            <center>
                <!--<img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt=""> -->

            </center>
        </div>
    </div>
    
     <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>
    
      <div class="row mt-5">

        <div class="col-md-2"></div>
        <div class="col-md-8">
            <svg height="35px" class="mb-2" fill="#5a67d8" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve" style="    fill: #8cc63f;">
                <g>
                    <g id="right_x5F_quote">
                        <g>
                            <path d="M0,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H0z" />
                            <path d="M20,4v12h8c0,4.41-3.586,8-8,8v4c6.617,0,12-5.383,12-12V4H20z" />
                        </g>
                    </g>
                </g>
            </svg>
            <p class="mt-2 text-base leading-6">
    Super easy process with Emily! Before Dana now Chloe arrived so loving. She is enjoying her new space. I am pretty sure Emily had the puppies on a potty training schedule.


            </p>
            <div class="text-sm mt-5">
                <a href="#" class="font-medium leading-none text-gray-900 hover:text-indigo-600 transition duration-500 ease-in-out">Ebonie M.</a>
                <!-- <p>CEO</p> -->
            </div>

        </div>
        <div class="col-md-2">
            <center>
                <!--<img class="w-48 h-full rounded-sm  mt-2 mb-2" src="<?= base_url() ?>assets/ss_4.jpg" alt=""> -->

            </center>
        </div>
    </div>
    
     <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <hr>
        </div>
        <div class="col-md-2"></div>
    </div>

<br><br>
</div>