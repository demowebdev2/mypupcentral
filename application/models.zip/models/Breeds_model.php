<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Breeds_model extends CI_Model {

	public function __construct() {
		parent::__construct();

	}


//select records
	function list_records(){

		
		$this->db->select('breeds.*');
		$this->db->from('breeds');	
		$query = $this->db->get();		
		if($query)
			{
			return $query->result();
		}
		else{
			return null;
		}

	}
	function deleteImage($id,$column_name)
{

   $sql="UPDATE breeds set ". $column_name ."= '' WHERE id=".$id ;
   $result =  $this->db->query($sql);	
   if($result)
   {
   	return true;
   }
   else
   {
   	return false;
   }
}
	

}

?>
