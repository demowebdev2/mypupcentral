<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct() {
		parent::__construct();

	}


    public function check_login($data)
    {
        $this->db->where('email',$data['login']);
        $this->db->or_where('phone',$data['login']);
		$this->db->limit(1);
		$query = $this->db->get('user_accounts');

			$record= $query->result();

            if ($record) {
                $pass_verify = $this->enc_lib->passHashDyc($data['password'], $record[0]->password);
                if ($pass_verify) {
                    return $record;
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
          
    }


}
