<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Common_model extends CI_Model {

	public function __construct() {
		parent::__construct();

	}

//create new record
	function create_record($params,$table)
	{
		foreach($params as $key => $value)
		{
			$this->db->set( $key, $value );
		}

		if($this->db->insert($table))
			return $this->db->insert_id();
		else
			return false;

	}

//select records
	function list_records($where,$table,$order_by,$order,$limit=NULL){
		if(!empty($where))
		{
			$this->db->where($where);}
		$this->db->order_by($order_by,$order);
		$this->db->limit($limit);
		$query = $this->db->get($table);

			return $query->result();

	}
	function list_row($table,$wheres)
	{
		$query = $this->db->get_where($table, $wheres, 1);
		return $query->row();
	}
	//Update records
	function update_records($data,$where,$table)
	{
		$this->db->set($data);
		$this->db->where($where);
		$this->db->update($table);
		if($this->db->trans_status() === FALSE)
			return FALSE;
		else{
			if($this->db->affected_rows()==0)
				return FALSE;
			else
				return TRUE;
		}

		return true;
	}

	function count_records($table,$where)
	{

		$this->db->select("*");
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->count_all_results();
	}

	function delete($table, $where)
	{
		$this->db->where($where);
		$this->db->delete($table);
		if($this->db->affected_rows()==0)
			return FALSE;
		else
			return TRUE;
	}
function get($where,$table)
	{
		$this->db->where($where);
		$result = $this->db->get($table);
		if($result)
			return $result->result();
		else
			return false;

	}
function change_status($where,$colum,$table)

{		
	$this->db->where($where);
   $result=$this->db->get($table);
   $status=$result->row_array()[$colum];

   if($status==1)
   {
   	$new_status=0;
   }
   else
   {
   	$new_status=1;
   }
	$this->db->set($colum,$new_status);

	$this->db->where($where);

	$this->db->update($table);

} 
function deleteImage($id,$column_name,$tablename)
{

   $sql="UPDATE ".$tablename." set ". $column_name ."= '' WHERE id=".$id ;
   $result =  $this->db->query($sql);	
   if($result)
   {
   	return true;
   }
   else
   {
   	return false;
   }
}

}

?>
