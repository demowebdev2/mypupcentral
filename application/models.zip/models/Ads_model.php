<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Ads_model extends CI_Model {

	public function __construct() {
		parent::__construct();

	}

public function get($id)
{
	// var_dump($id);exit;
	
		$this->db->select('posts.*,posts_pictures.picture,posts_videos.video,
			breeds.breed_name,
			user_accounts.name,
			user_accounts.email,
			user_accounts.phone,
			user_accounts.is_verified
			');
		$this->db->from('posts');
		$this->db->join('posts_pictures','posts_pictures.post_id=posts.id','left');
		$this->db->join('posts_videos','posts_videos.post_id=posts.id','left');
		$this->db->join('user_accounts','user_accounts.id=posts.user_id','left');
		$this->db->join('breeds','breeds.id=posts.category_id','left');
		$this->db->where('posts.id',$id);
		$this->db->group_by('posts.id');


	
		
		$query = $this->db->get();
			if($query)
			{

			return $query->result();
		}
		else{
			return null;
		}
}

public function get_details($where,$table)
{
	   $this->db->where($where);
		$result = $this->db->get($table);
		if($result)
			return $result->result();
		else
			return false;
}
//select records
	function list_records(){
		
		$this->db->select('posts.*,posts_pictures.picture,posts_videos.video');
		$this->db->from('posts');
		$this->db->join('posts_pictures','posts_pictures.post_id=posts.id','left');
		$this->db->join('posts_videos','posts_videos.post_id=posts.id','left');
		$this->db->group_by('posts.id');
		//$this->db->limit($limit);
		$query = $this->db->get();
			if($query)
			{
			return $query->result();
		}
		else{
			return null;
		}

	}
	function list_pending_requests(){
		
		$this->db->select('posts.*,posts_pictures.picture,posts_videos.video');
		$this->db->from('posts');
		$this->db->join('posts_pictures','posts_pictures.post_id=posts.id','left');
		$this->db->join('posts_videos','posts_videos.post_id=posts.id','left');
		$this->db->where('reviewed',0);
		$this->db->group_by('posts.id');
		//$this->db->limit($limit);
		$query = $this->db->get();
			if($query)
			{
			return $query->result();
		}
		else{
			return null;
		}

	}
	function get_filtered_general($where = "")
	{
		$this->make_query();
		$query = $this->db->get();

		return $query->num_rows();
	}
   function make_datatables_breeder_inner_join($where)
	{
		$this->make_query($where);
		if ($_POST["length"] != -1) {
			$this->db->limit($_POST['length'], $_POST['start']);
		}
		$query = $this->db->get();

		return $query->result();
	}
	
	public function getbreeds()
	{
		$this->db->select('*');
		$this->db->from('breeds');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function addad($table,$data)
	{
		$this->db->insert($table,$data);
        return $this->db->insert_id();
	}

}

?>
