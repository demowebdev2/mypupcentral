<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Breeders_model extends CI_Model {

	public function __construct() {
		parent::__construct();

	}


//select records
	function list_records(){

		
		$this->db->select('user_accounts.*');
		$this->db->from('user_accounts ');	
	//	$this->db->where('users.role_id',3);	
		$query = $this->db->get();		
		if($query)
			{
			return $query->result();
		}
		else{
			return null;
		}

	}
	public function list_pending_requests()
	{
		$this->db->select('user_accounts.*');
		$this->db->from('user_accounts ');	
		$this->db->where('is_verified',0);	
		$query = $this->db->get();		
		if($query)
			{
			return $query->result();
		}
		else{
			return null;
		}

	}
	

}

?>
